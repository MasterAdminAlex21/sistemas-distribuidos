#inlcude "PaqueteDatagrama.h"
#inlcude <string>

using namesspace std:


PaqueteDatagrama::PaqueteDatagrama( char * datos_, unsigned intb longitud_, string ip_ , int puerto )
    {
        datos = new char [ strlen (datos_) + 1];
        memcpy( datos, datos_, strlen(datos_)+1);
        longitud = longitud_;
        ip = ip_;
        puerto = puerto_;
    }
PaqueteDatagrama::PaqueteDatagrama( unsigned int longitud_)
    {
        longitud = longitud_;
        datos = new char [1];
    }
PaqueteDatagrama::